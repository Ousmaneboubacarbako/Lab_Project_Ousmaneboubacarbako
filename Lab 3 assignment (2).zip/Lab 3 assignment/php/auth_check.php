<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
// If not, redirect to login page
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: Login.php');
    exit;
}

// Session timeout configuration (2 hours = 7200 seconds)
$timeout_duration = 7200;

// Check if session has expired due to inactivity
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity']) > $timeout_duration) {
    
    // Session expired - clear session data
    session_unset();
    session_destroy();
    
    // Redirect to login with timeout parameter
    header('Location: Login.php?timeout=1');
    exit;
}

// Update last activity timestamp
// This resets the timeout counter
$_SESSION['last_activity'] = time();

// Session regeneration for security
// Prevents session fixation attacks
if (!isset($_SESSION['created'])) {
    $_SESSION['created'] = time();
} else if (time() - $_SESSION['created'] > 1800) {
    // Regenerate session ID every 30 minutes
    session_regenerate_id(true);
    $_SESSION['created'] = time();
}

// If we reach here, user is authenticated and can access the page
?>