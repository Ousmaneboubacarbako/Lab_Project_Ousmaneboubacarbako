<?php
/**
 * Get Courses Handler
 * Returns courses based on user role
 * - Faculty: courses they created
 * - Student: all available courses and their enrolled courses
 */

session_start();
header('Content-Type: application/json');
require_once 'db_connect.php';

// Check authentication
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

try {
    if ($role === 'faculty') {
        // Get courses created by this faculty with enrollment stats
        $stmt = $conn->prepare("
            SELECT 
                c.course_id,
                c.course_code,
                c.course_name,
                c.description,
                c.credits,
                c.semester,
                c.status,
                c.created_at,
                COUNT(DISTINCT ce.student_id) as enrolled_count,
                COUNT(DISTINCT CASE WHEN cr.status = 'pending' THEN cr.request_id END) as pending_requests
            FROM courses c
            LEFT JOIN course_enrollments ce ON c.course_id = ce.course_id AND ce.status = 'active'
            LEFT JOIN course_requests cr ON c.course_id = cr.course_id AND cr.status = 'pending'
            WHERE c.faculty_id = ?
            GROUP BY c.course_id
            ORDER BY c.created_at DESC
        ");
        $stmt->execute([$user_id]);
        $courses = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'courses' => $courses,
            'count' => count($courses)
        ]);
        
    } elseif ($role === 'student') {
        // Get action type (enrolled, available, or all)
        $action = isset($_GET['action']) ? $_GET['action'] : 'all';
        
        if ($action === 'enrolled') {
            // Get courses the student is enrolled in
            $stmt = $conn->prepare("
                SELECT 
                    c.course_id,
                    c.course_code,
                    c.course_name,
                    c.description,
                    c.credits,
                    c.semester,
                    c.status,
                    CONCAT(u.first_name, ' ', u.last_name) as faculty_name,
                    ce.enrolled_at
                FROM course_enrollments ce
                INNER JOIN courses c ON ce.course_id = c.course_id
                LEFT JOIN users u ON c.faculty_id = u.user_id
                WHERE ce.student_id = ? AND ce.status = 'active'
                ORDER BY ce.enrolled_at DESC
            ");
            $stmt->execute([$user_id]);
            $courses = $stmt->fetchAll();
            
        } elseif ($action === 'available') {
            // Get courses available to join (not enrolled, no pending request)
            $stmt = $conn->prepare("
                SELECT 
                    c.course_id,
                    c.course_code,
                    c.course_name,
                    c.description,
                    c.credits,
                    c.semester,
                    CONCAT(u.first_name, ' ', u.last_name) as faculty_name,
                    COUNT(DISTINCT ce.student_id) as enrolled_count,
                    CASE 
                        WHEN cr.status = 'pending' THEN 'pending'
                        WHEN cr.status = 'rejected' THEN 'rejected'
                        ELSE NULL
                    END as request_status
                FROM courses c
                LEFT JOIN users u ON c.faculty_id = u.user_id
                LEFT JOIN course_enrollments ce ON c.course_id = ce.course_id AND ce.status = 'active'
                LEFT JOIN course_requests cr ON c.course_id = cr.course_id AND cr.student_id = ?
                WHERE c.status = 'active'
                AND c.course_id NOT IN (
                    SELECT course_id FROM course_enrollments 
                    WHERE student_id = ? AND status = 'active'
                )
                GROUP BY c.course_id
                ORDER BY c.course_name ASC
            ");
            $stmt->execute([$user_id, $user_id]);
            $courses = $stmt->fetchAll();
            
        } else {
            // Get all courses with enrollment status
            $stmt = $conn->prepare("
                SELECT 
                    c.course_id,
                    c.course_code,
                    c.course_name,
                    c.description,
                    c.credits,
                    c.semester,
                    c.status,
                    CONCAT(u.first_name, ' ', u.last_name) as faculty_name,
                    COUNT(DISTINCT ce.student_id) as enrolled_count,
                    MAX(CASE WHEN ce2.student_id = ? THEN 'enrolled' ELSE NULL END) as my_status
                FROM courses c
                LEFT JOIN users u ON c.faculty_id = u.user_id
                LEFT JOIN course_enrollments ce ON c.course_id = ce.course_id AND ce.status = 'active'
                LEFT JOIN course_enrollments ce2 ON c.course_id = ce2.course_id AND ce2.student_id = ?
                WHERE c.status = 'active'
                GROUP BY c.course_id
                ORDER BY c.course_name ASC
            ");
            $stmt->execute([$user_id, $user_id]);
            $courses = $stmt->fetchAll();
        }
        
        echo json_encode([
            'success' => true,
            'courses' => $courses,
            'count' => count($courses),
            'action' => $action
        ]);
        
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid role']);
    }
    
} catch(PDOException $e) {
    error_log("Get courses error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'An error occurred while fetching courses'
    ]);
}
?>