<?php
// Start session to access session variables
session_start();

// Set response header to JSON format
header('Content-Type: application/json');

try {
    // Clear all session variables
    $_SESSION = array();
    
    // Delete the session cookie from user's browser
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }
    
    // Destroy the session on the server
    session_destroy();
    
    // Return success response
    echo json_encode([
        'logout' => true,
        'message' => 'Logged out successfully'
    ]);
    
} catch(Exception $e) {
    // Log error if logout fails
    error_log("Logout error: " . $e->getMessage());
    
    // Return error response
    echo json_encode([
        'logout' => false,
        'message' => 'An error occurred during logout'
    ]);
}
?>