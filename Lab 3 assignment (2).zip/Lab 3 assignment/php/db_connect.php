<?php
// Function to load environment variables from .env file
function loadEnv($path) {
    // Check if .env file exists
    if (!file_exists($path)) {
        die("Environment file not found!");
    }
    
    // Read all lines from .env file, ignoring empty lines
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    
    // Loop through each line
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;

        list($key, $value) = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value, '"\''); // Remove quotes if present
        
        putenv("$key=$value");
        $_ENV[$key] = $value;
    }
}

// Load the .env file from current directory
loadEnv(__DIR__ . '/.env');

// Get database credentials from environment variables
$host = getenv('localhost');         // e.g., localhost
$dbname = getenv('Attendancedb');       // e.g., attendance_db
$username = getenv('ousmane.bako'); // e.g., root
$password = getenv('Ousou2004'); // e.g., your password

try {
    // Create PDO connection with UTF-8 character set
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    
    // Set error mode to throw exceptions (easier debugging)
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Set default fetch mode to associative array
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    error_log("Connection failed: " . $e->getMessage());
    die(json_encode([
        'success' => false,
        'message' => 'Database connection failed'
    ]));
}
?>