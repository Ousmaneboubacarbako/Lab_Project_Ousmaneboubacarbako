<?php
// Start session to access session variables
session_start();
header('Content-Type: application/json');
require_once 'db_connect.php';

// Check if user is logged in and is faculty
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

// Only faculty can create courses
if ($_SESSION['role'] !== 'faculty') {
    echo json_encode(['success' => false, 'message' => 'Only faculty can create courses']);
    exit;
}

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($input['course_code']) || !isset($input['course_name'])) {
    echo json_encode(['success' => false, 'message' => 'Course code and name are required']);
    exit;
}

// Sanitize inputs
$course_code = trim(strtoupper($input['course_code']));
$course_name = trim($input['course_name']);
$description = isset($input['description']) ? trim($input['description']) : '';
$credits = isset($input['credits']) ? intval($input['credits']) : 3;
$semester = isset($input['semester']) ? trim($input['semester']) : '';

// Validate course code format (e.g., CS101, MATH201)
if (!preg_match('/^[A-Z]{2,4}\d{3}$/', $course_code)) {
    echo json_encode([
        'success' => false, 
        'message' => 'Invalid course code format. Use format like CS101 or MATH201'
    ]);
    exit;
}

// Validate credits (1-6)
if ($credits < 1 || $credits > 6) {
    echo json_encode(['success' => false, 'message' => 'Credits must be between 1 and 6']);
    exit;
}

try {
    // Check if course code already exists
    $checkStmt = $conn->prepare("SELECT course_id FROM courses WHERE course_code = ?");
    $checkStmt->execute([$course_code]);
    
    if ($checkStmt->rowCount() > 0) {
        echo json_encode([
            'success' => false, 
            'message' => 'Course code already exists'
        ]);
        exit;
    }
    
    // Insert new course
    $stmt = $conn->prepare("
        INSERT INTO courses (course_code, course_name, description, credits, semester, faculty_id, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $success = $stmt->execute([
        $course_code, 
        $course_name, 
        $description, 
        $credits, 
        $semester, 
        $_SESSION['user_id']
    ]);
    
    if ($success) {
        $course_id = $conn->lastInsertId();
        
        echo json_encode([
            'success' => true, 
            'message' => 'Course created successfully!',
            'course' => [
                'course_id' => $course_id,
                'course_code' => $course_code,
                'course_name' => $course_name,
                'description' => $description,
                'credits' => $credits,
                'semester' => $semester
            ]
        ]);
    } else {
        echo json_encode([
            'success' => false, 
            'message' => 'Failed to create course'
        ]);
    }
    
} catch(PDOException $e) {
    error_log("Create course error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'An error occurred while creating the course'
    ]);
}
?>