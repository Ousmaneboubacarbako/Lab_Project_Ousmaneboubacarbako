<?php
// Start session to track user state
session_start();

// Set response header to JSON format
header('Content-Type: application/json');

// Include database connection
require_once 'db_connect.php';

// Check if request method is POST (only POST allowed)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get JSON input from request body
$input = json_decode(file_get_contents('php://input'), true);

// Validate that all required fields are present
if (!isset($input['firstName']) || !isset($input['lastName']) || 
    !isset($input['email']) || !isset($input['password']) || !isset($input['role'])) {
    echo json_encode(['success' => false, 'message' => 'All fields required']);
    exit;
}

// Sanitize input data (remove extra spaces)
$firstName = trim($input['firstName']);
$lastName = trim($input['lastName']);
$email = trim($input['email']);
$password = $input['password'];
$role = trim($input['role']);

// Server-side validation: Check email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit;
}

// Server-side validation: Check password length
if (strlen($password) < 8) {
    echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters']);
    exit;
}

// Server-side validation: Check role is valid
$validRoles = ['student', 'faculty', 'fi'];
if (!in_array($role, $validRoles)) {
    echo json_encode(['success' => false, 'message' => 'Invalid role selected']);
    exit;
}

try {
    // Check if email already exists in database
    $checkStmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
    $checkStmt->execute([$email]);
    
    if ($checkStmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'Email already registered']);
        exit;
    }
    
    // Hash the password securely 
    // NEVER store plain text passwords!
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Prepare SQL statement with placeholders (prevents SQL injection)
    $stmt = $conn->prepare("
        INSERT INTO users (first_name, last_name, email, password, role, created_at) 
        VALUES (?, ?, ?, ?, ?, NOW())
    ");
    
    // Execute statement with actual values
    $success = $stmt->execute([$firstName, $lastName, $email, $hashedPassword, $role]);
    
    // Return response based on success
    if ($success) {
        echo json_encode(['success' => true, 'message' => 'Registration successful!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Registration failed']);
    }
    
} catch(PDOException $e) {
    // Log database error (don't expose details to user)
    error_log("Signup error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred during registration']);
}
?>