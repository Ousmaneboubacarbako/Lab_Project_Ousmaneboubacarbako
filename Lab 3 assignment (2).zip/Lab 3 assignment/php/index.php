<?php
// Start session to check login status
session_start();

// Check if user is already logged in
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    
    // User is logged in - redirect based on their role
    switch($_SESSION['role']) {
        case 'student':
            header('Location: StuDashboard.php');
            break;
            
        case 'faculty':
            header('Location: FDashboard.php');
            break;
            
        case 'fi':
            header('Location: Dashboard.php');
            break;
            
        default:
            // Unknown role - send to login
            header('Location: Login.php');
    }
    exit;
}

// User is not logged in - redirect to login page
header('Location: Login.php');
exit;
?>