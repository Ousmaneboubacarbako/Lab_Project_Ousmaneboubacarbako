<?php

// Start session to store user login state
session_start();

// Set response header to JSON format
header('Content-Type: application/json');

// Include database connection
require_once 'db_connect.php';

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get JSON input from request body
$input = json_decode(file_get_contents('php://input'), true);

// Validate all required fields are present
if (!isset($input['email']) || !isset($input['password']) || !isset($input['role'])) {
    echo json_encode(['success' => false, 'message' => 'All fields required']);
    exit;
}

// Sanitize input data
$email = trim($input['email']);
$password = $input['password'];
$role = trim($input['role']);

try {
    // Using prepared statement to prevent SQL injection
    $stmt = $conn->prepare("
        SELECT user_id, first_name, last_name, email, password, role 
        FROM users 
        WHERE email = ? AND role = ?
    ");
    
    // Execute query with email and role
    $stmt->execute([$email, $role]);
    
    // Fetch user data
    $user = $stmt->fetch();
    
    // Check if user exists
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'Invalid credentials or role']);
        exit;
    }
    
    // Verify password against hashed password in database
    if (password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $user['first_name'] . ' ' . $user['last_name'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['logged_in'] = true;
        $_SESSION['last_activity'] = time(); // Track last activity for timeout
        
        // Return success response with user data
        echo json_encode([
            'success' => true,
            'username' => $_SESSION['username'],
            'user_id' => $_SESSION['user_id'],
            'role' => $_SESSION['role'],
            'message' => 'Login successful!'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid credentials']);
    }
    
} catch(PDOException $e) {
    // Log error (don't expose database details to user)
    error_log("Login error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred during login']);
}
?>