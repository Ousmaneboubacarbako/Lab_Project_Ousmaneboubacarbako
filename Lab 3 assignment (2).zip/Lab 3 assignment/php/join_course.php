<?php
/**
 * Join Course Request Handler
 * Allows students to request to join courses
 */

session_start();
header('Content-Type: application/json');
require_once 'db_connect.php';

// Check authentication
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

// Only students can join courses
if ($_SESSION['role'] !== 'student') {
    echo json_encode(['success' => false, 'message' => 'Only students can join courses']);
    exit;
}

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($input['course_id'])) {
    echo json_encode(['success' => false, 'message' => 'Course ID is required']);
    exit;
}

$course_id = intval($input['course_id']);
$student_id = $_SESSION['user_id'];
$request_message = isset($input['message']) ? trim($input['message']) : '';

try {
    // Check if course exists and is active
    $courseStmt = $conn->prepare("SELECT course_id, course_name, status FROM courses WHERE course_id = ?");
    $courseStmt->execute([$course_id]);
    $course = $courseStmt->fetch();
    
    if (!$course) {
        echo json_encode(['success' => false, 'message' => 'Course not found']);
        exit;
    }
    
    if ($course['status'] !== 'active') {
        echo json_encode(['success' => false, 'message' => 'Course is not active']);
        exit;
    }
    
    // Check if already enrolled
    $enrollStmt = $conn->prepare("
        SELECT enrollment_id FROM course_enrollments 
        WHERE course_id = ? AND student_id = ? AND status = 'active'
    ");
    $enrollStmt->execute([$course_id, $student_id]);
    
    if ($enrollStmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'You are already enrolled in this course']);
        exit;
    }
    
    // Check if there's already a pending request
    $requestStmt = $conn->prepare("
        SELECT request_id FROM course_requests 
        WHERE course_id = ? AND student_id = ? AND status = 'pending'
    ");
    $requestStmt->execute([$course_id, $student_id]);
    
    if ($requestStmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'You already have a pending request for this course']);
        exit;
    }
    
    // Create join request
    $insertStmt = $conn->prepare("
        INSERT INTO course_requests (course_id, student_id, request_message, status, requested_at) 
        VALUES (?, ?, ?, 'pending', NOW())
    ");
    
    $success = $insertStmt->execute([$course_id, $student_id, $request_message]);
    
    if ($success) {
        echo json_encode([
            'success' => true, 
            'message' => 'Join request sent successfully! Waiting for faculty approval.',
            'request_id' => $conn->lastInsertId()
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to send join request']);
    }
    
} catch(PDOException $e) {
    error_log("Join course error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'An error occurred while processing your request'
    ]);
}
?>