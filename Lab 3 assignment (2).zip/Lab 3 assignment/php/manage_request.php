<?php
/**
 * Manage Course Requests Handler
 * Allows faculty to view, approve, or reject student join requests
 */

session_start();
header('Content-Type: application/json');
require_once 'db_connect.php';

// Check authentication
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

// Only faculty can manage requests
if ($_SESSION['role'] !== 'faculty') {
    echo json_encode(['success' => false, 'message' => 'Only faculty can manage course requests']);
    exit;
}

$faculty_id = $_SESSION['user_id'];

// GET: Fetch pending requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : null;
        
        if ($course_id) {
            // Get requests for specific course
            $stmt = $conn->prepare("
                SELECT 
                    cr.request_id,
                    cr.course_id,
                    cr.student_id,
                    cr.request_message,
                    cr.status,
                    cr.requested_at,
                    CONCAT(u.first_name, ' ', u.last_name) as student_name,
                    u.email as student_email,
                    c.course_code,
                    c.course_name
                FROM course_requests cr
                INNER JOIN users u ON cr.student_id = u.user_id
                INNER JOIN courses c ON cr.course_id = c.course_id
                WHERE cr.course_id = ? AND c.faculty_id = ? AND cr.status = 'pending'
                ORDER BY cr.requested_at ASC
            ");
            $stmt->execute([$course_id, $faculty_id]);
        } else {
            // Get all pending requests for faculty's courses
            $stmt = $conn->prepare("
                SELECT 
                    cr.request_id,
                    cr.course_id,
                    cr.student_id,
                    cr.request_message,
                    cr.status,
                    cr.requested_at,
                    CONCAT(u.first_name, ' ', u.last_name) as student_name,
                    u.email as student_email,
                    c.course_code,
                    c.course_name
                FROM course_requests cr
                INNER JOIN users u ON cr.student_id = u.user_id
                INNER JOIN courses c ON cr.course_id = c.course_id
                WHERE c.faculty_id = ? AND cr.status = 'pending'
                ORDER BY cr.requested_at ASC
            ");
            $stmt->execute([$faculty_id]);
        }
        
        $requests = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'requests' => $requests,
            'count' => count($requests)
        ]);
        
    } catch(PDOException $e) {
        error_log("Fetch requests error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error fetching requests']);
    }
    exit;
}

// POST: Approve or reject request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['request_id']) || !isset($input['action'])) {
        echo json_encode(['success' => false, 'message' => 'Request ID and action are required']);
        exit;
    }
    
    $request_id = intval($input['request_id']);
    $action = $input['action']; // 'approve' or 'reject'
    $review_note = isset($input['note']) ? trim($input['note']) : '';
    
    if (!in_array($action, ['approve', 'reject'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        exit;
    }
    
    try {
        // Get request details and verify faculty owns the course
        $stmt = $conn->prepare("
            SELECT cr.*, c.faculty_id, c.course_name
            FROM course_requests cr
            INNER JOIN courses c ON cr.course_id = c.course_id
            WHERE cr.request_id = ? AND c.faculty_id = ? AND cr.status = 'pending'
        ");
        $stmt->execute([$request_id, $faculty_id]);
        $request = $stmt->fetch();
        
        if (!$request) {
            echo json_encode(['success' => false, 'message' => 'Request not found or already processed']);
            exit;
        }
        
        // Start transaction
        $conn->beginTransaction();
        
        if ($action === 'approve') {
            // Update request status to approved
            $updateStmt = $conn->prepare("
                UPDATE course_requests 
                SET status = 'approved', reviewed_at = NOW(), reviewed_by = ?, review_note = ?
                WHERE request_id = ?
            ");
            $updateStmt->execute([$faculty_id, $review_note, $request_id]);
            
            // Enroll student in course
            $enrollStmt = $conn->prepare("
                INSERT INTO course_enrollments (course_id, student_id, enrolled_at, status)
                VALUES (?, ?, NOW(), 'active')
                ON DUPLICATE KEY UPDATE status = 'active'
            ");
            $enrollStmt->execute([$request['course_id'], $request['student_id']]);
            
            $message = 'Student approved and enrolled successfully!';
            
        } else {
            // Reject request
            $updateStmt = $conn->prepare("
                UPDATE course_requests 
                SET status = 'rejected', reviewed_at = NOW(), reviewed_by = ?, review_note = ?
                WHERE request_id = ?
            ");
            $updateStmt->execute([$faculty_id, $review_note, $request_id]);
            
            $message = 'Request rejected successfully';
        }
        
        // Commit transaction
        $conn->commit();
        
        echo json_encode([
            'success' => true,
            'message' => $message,
            'action' => $action
        ]);
        
    } catch(PDOException $e) {
        // Rollback on error
        $conn->rollBack();
        error_log("Manage request error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error processing request']);
    }
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid request method']);
?>