document.getElementById('signupForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  
  const firstName = document.getElementById('firstName').value;
  const lastName = document.getElementById('lastName').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('C_password').value;
  const role = document.getElementById('signupRole').value;

  // Client-side validation
  if (!role) {
    Swal.fire({
      icon: 'warning',
      title: 'Missing Role',
      text: 'Please select your role',
      confirmButtonColor: '#f39c12'
    });
    return;
  }

  if (password !== confirmPassword) {
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Passwords do not match!',
      confirmButtonColor: '#d33',
      showClass: {
        popup: 'animate__animated animate__shakeX'
      }
    });
    return;
  }

  if (password.length < 8) {
    Swal.fire({
      icon: 'warning',
      title: 'Weak Password',
      text: 'Password must be at least 8 characters long!',
      confirmButtonColor: '#f39c12'
    });
    return;
  }

  // Show loading
  Swal.fire({
    title: 'Creating your account...',
    allowOutsideClick: false,
    didOpen: () => {
      Swal.showLoading();
    }
  });

  try {
    // Send data to server
    const response = await fetch('signup.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        firstName: firstName,
        lastName: lastName,
        email: email,
        password: password,
        role: role
      })
    });

    const data = await response.json();

    if (data.success) {
      // Success message
      Swal.fire({
        icon: 'success',
        title: 'Registration Successful!',
        html: `Welcome, <strong>${firstName} ${lastName}</strong>!<br>Your account has been created.`,
        confirmButtonColor: '#667eea',
        confirmButtonText: 'Continue to Login',
        showClass: {
          popup: 'animate__animated animate__fadeInDown'
        },
        hideClass: {
          popup: 'animate__animated animate__fadeOutUp'
        },
        timer: 3000,
        timerProgressBar: true
      }).then(() => {
        // Redirect to login page
        window.location.href = 'Login.php';
      });
    } else {
      // Error message
      Swal.fire({
        icon: 'error',
        title: 'Registration Failed',
        text: data.message || 'An error occurred. Please try again.',
        confirmButtonColor: '#d33'
      });
    }

  } catch (error) {
    console.error('Error:', error);
    Swal.fire({
      icon: 'error',
      title: 'Network Error',
      text: 'Could not connect to server. Please try again.',
      confirmButtonColor: '#d33'
    });
  }
});