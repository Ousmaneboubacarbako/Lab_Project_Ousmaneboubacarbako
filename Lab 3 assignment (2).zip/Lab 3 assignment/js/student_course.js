/**
 * Student Course Management JavaScript
 * Handles browsing courses and requesting to join
 */

let allAvailableCourses = [];
let selectedCourse = null;

// Load courses when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadEnrolledCourses();
    loadAvailableCourses();
});

// Load enrolled courses
async function loadEnrolledCourses() {
    try {
        const response = await fetch('get_courses.php?action=enrolled');
        const data = await response.json();
        
        const courseList = document.getElementById('enrolled-courses-list');
        
        if (data.success && data.courses.length > 0) {
            courseList.innerHTML = data.courses.map(course => `
                <div class="course-card">
                    <h3>${course.course_code} - ${course.course_name}</h3>
                    <p>${course.description || 'No description available'}</p>
                    <div class="course-meta">
                        <strong>Faculty:</strong> ${course.faculty_name} | 
                        <strong>Credits:</strong> ${course.credits} | 
                        <strong>Semester:</strong> ${course.semester || 'N/A'}
                    </div>
                    <div class="course-info">
                        <span style="font-size: 12px; color: #888;">
                            Enrolled: ${new Date(course.enrolled_at).toLocaleDateString()}
                        </span>
                        <span class="badge badge-success">Enrolled</span>
                    </div>
                </div>
            `).join('');
        } else {
            courseList.innerHTML = `
                <p style="text-align: center; padding: 2rem; color: #666;">
                    You haven't enrolled in any courses yet.<br>
                    Browse available courses below to get started!
                </p>
            `;
        }
    } catch (error) {
        console.error('Error loading enrolled courses:', error);
        document.getElementById('enrolled-courses-list').innerHTML = 
            '<p style="color: red; text-align: center;">Error loading courses</p>';
    }
}

// Load available courses
async function loadAvailableCourses() {
    try {
        const response = await fetch('get_courses.php?action=available');
        const data = await response.json();
        
        allAvailableCourses = data.courses || [];
        displayAvailableCourses(allAvailableCourses);
        
    } catch (error) {
        console.error('Error loading available courses:', error);
        document.getElementById('available-courses-list').innerHTML = 
            '<p style="color: red; text-align: center;">Error loading courses</p>';
    }
}

// Display available courses
function displayAvailableCourses(courses) {
    const courseList = document.getElementById('available-courses-list');
    
    if (courses.length > 0) {
        courseList.innerHTML = courses.map(course => {
            let actionButton = '';
            let statusBadge = '';
            
            if (course.request_status === 'pending') {
                statusBadge = '<span class="badge badge-warning">Request Pending</span>';
                actionButton = '<button class="btn-join" disabled>Pending Approval</button>';
            } else if (course.request_status === 'rejected') {
                statusBadge = '<span class="badge badge-danger">Request Rejected</span>';
                actionButton = `<button class="btn-join" onclick="requestJoinCourse(${course.course_id}, '${course.course_code}', '${course.course_name}')">Request Again</button>`;
            } else {
                actionButton = `<button class="btn-join" onclick="requestJoinCourse(${course.course_id}, '${course.course_code}', '${course.course_name}')">Request to Join</button>`;
            }
            
            return `
                <div class="course-card">
                    <h3>${course.course_code} - ${course.course_name} ${statusBadge}</h3>
                    <p>${course.description || 'No description available'}</p>
                    <div class="course-meta">
                        <strong>Faculty:</strong> ${course.faculty_name} | 
                        <strong>Credits:</strong> ${course.credits} | 
                        <strong>Semester:</strong> ${course.semester || 'N/A'}
                    </div>
                    <div class="course-info">
                        <span><span class="badge badge-info">${course.enrolled_count} Students Enrolled</span></span>
                        <span>${actionButton}</span>
                    </div>
                </div>
            `;
        }).join('');
    } else {
        courseList.innerHTML = `
            <p style="text-align: center; padding: 2rem; color: #666;">
                No available courses to join at this time.
            </p>
        `;
    }
}

// Filter courses by search
function filterCourses() {
    const searchTerm = document.getElementById('courseSearch').value.toLowerCase();
    const filteredCourses = allAvailableCourses.filter(course => 
        course.course_code.toLowerCase().includes(searchTerm) ||
        course.course_name.toLowerCase().includes(searchTerm) ||
        (course.faculty_name && course.faculty_name.toLowerCase().includes(searchTerm))
    );
    displayAvailableCourses(filteredCourses);
}

// Open browse courses modal
function openBrowseCoursesModal() {
    document.getElementById('browseCoursesModal').style.display = 'block';
    loadModalCourses();
}

// Close browse courses modal
function closeBrowseCoursesModal() {
    document.getElementById('browseCoursesModal').style.display = 'none';
}

// Load courses in modal
async function loadModalCourses() {
    try {
        const response = await fetch('get_courses.php?action=all');
        const data = await response.json();
        
        const modalList = document.getElementById('modal-courses-list');
        
        if (data.success && data.courses.length > 0) {
            modalList.innerHTML = data.courses.map(course => `
                <div class="course-card" style="margin-bottom: 15px;">
                    <h4>${course.course_code} - ${course.course_name}</h4>
                    <p style="font-size: 13px;">${course.description || 'No description'}</p>
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 10px;">
                        <span style="font-size: 12px; color: #666;">
                            ${course.faculty_name} | ${course.credits} credits
                        </span>
                        ${course.my_status === 'enrolled' ? 
                            '<span class="badge badge-success">Enrolled</span>' :
                            `<button class="btn-join btn-sm" onclick="requestJoinCourse(${course.course_id}, '${course.course_code}', '${course.course_name}')">Join</button>`
                        }
                    </div>
                </div>
            `).join('');
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// Filter modal courses
function filterModalCourses() {
    const searchTerm = document.getElementById('modalCourseSearch').value.toLowerCase();
    const cards = document.querySelectorAll('#modal-courses-list .course-card');
    
    cards.forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(searchTerm) ? 'block' : 'none';
    });
}

// Request to join course
function requestJoinCourse(courseId, courseCode, courseName) {
    selectedCourse = { id: courseId, code: courseCode, name: courseName };
    
    document.getElementById('join_course_id').value = courseId;
    document.getElementById('joinCourseInfo').innerHTML = `
        <div style="padding: 15px; background: #f8f9fa; border-radius: 5px; margin-bottom: 15px;">
            <h3 style="margin: 0 0 5px 0; color: #3498db;">${courseCode}</h3>
            <p style="margin: 0; color: #666;">${courseName}</p>
        </div>
    `;
    
    document.getElementById('joinCourseModal').style.display = 'block';
    closeBrowseCoursesModal();
}

// Close join course modal
function closeJoinCourseModal() {
    document.getElementById('joinCourseModal').style.display = 'none';
    document.getElementById('joinCourseForm').reset();
    selectedCourse = null;
}

// Handle join course form submission
document.getElementById('joinCourseForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = {
        course_id: document.getElementById('join_course_id').value,
        message: document.getElementById('join_message').value
    };
    
    // Show loading
    Swal.fire({
        title: 'Sending request...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    try {
        const response = await fetch('join_course.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Request Sent!',
                text: data.message,
                confirmButtonColor: '#2ecc71'
            });
            closeJoinCourseModal();
            loadAvailableCourses(); // Reload to update status
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Request Failed',
                text: data.message,
                confirmButtonColor: '#d33'
            });
        }
    } catch (error) {
        console.error('Error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Network Error',
            text: 'Could not connect to server',
            confirmButtonColor: '#d33'
        });
    }
});

// Close modals when clicking outside
window.onclick = function(event) {
    const browseModal = document.getElementById('browseCoursesModal');
    const joinModal = document.getElementById('joinCourseModal');
    
    if (event.target == browseModal) {
        closeBrowseCoursesModal();
    }
    if (event.target == joinModal) {
        closeJoinCourseModal();
    }
}