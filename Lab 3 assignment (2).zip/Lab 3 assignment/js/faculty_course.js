/**
 * Faculty Course Management JavaScript
 * Handles course creation, viewing, and managing student requests
 */

// Load courses and requests when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadFacultyCourses();
    loadPendingRequests();
});

// Open create course modal
function openCreateCourseModal() {
    document.getElementById('createCourseModal').style.display = 'block';
}

// Close create course modal
function closeCreateCourseModal() {
    document.getElementById('createCourseModal').style.display = 'none';
    document.getElementById('createCourseForm').reset();
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('createCourseModal');
    if (event.target == modal) {
        closeCreateCourseModal();
    }
}

// Handle create course form submission
document.getElementById('createCourseForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = {
        course_code: document.getElementById('course_code').value.toUpperCase(),
        course_name: document.getElementById('course_name').value,
        description: document.getElementById('description').value,
        credits: document.getElementById('credits').value,
        semester: document.getElementById('semester').value
    };
    
    // Show loading
    Swal.fire({
        title: 'Creating course...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    try {
        const response = await fetch('create_course.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Course Created!',
                text: data.message,
                confirmButtonColor: '#2ecc71'
            });
            closeCreateCourseModal();
            loadFacultyCourses(); // Reload course list
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Creation Failed',
                text: data.message,
                confirmButtonColor: '#d33'
            });
        }
    } catch (error) {
        console.error('Error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Network Error',
            text: 'Could not connect to server',
            confirmButtonColor: '#d33'
        });
    }
});

// Load faculty courses
async function loadFacultyCourses() {
    try {
        const response = await fetch('get_courses.php');
        const data = await response.json();
        
        const courseList = document.getElementById('course-list');
        
        if (data.success && data.courses.length > 0) {
            courseList.innerHTML = data.courses.map(course => `
                <div class="course-card">
                    <h3>${course.course_code} - ${course.course_name}</h3>
                    <p>${course.description || 'No description available'}</p>
                    <div class="course-info">
                        <span>
                            <strong>Credits:</strong> ${course.credits} | 
                            <strong>Semester:</strong> ${course.semester || 'N/A'}
                        </span>
                        <span>
                            <span class="badge badge-success">${course.enrolled_count} Students</span>
                            ${course.pending_requests > 0 ? 
                                `<span class="badge badge-warning">${course.pending_requests} Pending</span>` 
                                : ''}
                        </span>
                    </div>
                    ${course.pending_requests > 0 ? 
                        `<button onclick="viewCourseRequests(${course.course_id})" 
                                style="margin-top: 10px; background: #f39c12;">
                            View ${course.pending_requests} Pending Request${course.pending_requests > 1 ? 's' : ''}
                        </button>` 
                        : ''}
                </div>
            `).join('');
        } else {
            courseList.innerHTML = '<p style="text-align: center; padding: 2rem; color: #666;">No courses created yet. Click "Create New Course" to get started!</p>';
        }
    } catch (error) {
        console.error('Error loading courses:', error);
        document.getElementById('course-list').innerHTML = '<p style="color: red; text-align: center;">Error loading courses</p>';
    }
}

// Load pending requests
async function loadPendingRequests() {
    try {
        const response = await fetch('manage_requests.php');
        const data = await response.json();
        
        const requestsList = document.getElementById('requests-list');
        
        if (data.success && data.requests.length > 0) {
            requestsList.innerHTML = data.requests.map(request => `
                <div class="request-card">
                    <h4>${request.student_name} <span class="badge badge-info">${request.student_email}</span></h4>
                    <p><strong>Course:</strong> ${request.course_code} - ${request.course_name}</p>
                    ${request.request_message ? 
                        `<p><strong>Message:</strong> ${request.request_message}</p>` 
                        : ''}
                    <p style="font-size: 12px; color: #888;">
                        Requested: ${new Date(request.requested_at).toLocaleString()}
                    </p>
                    <div class="request-actions">
                        <button onclick="handleRequest(${request.request_id}, 'approve')" 
                                class="btn-sm" style="background: #2ecc71;">
                            ✓ Approve
                        </button>
                        <button onclick="handleRequest(${request.request_id}, 'reject')" 
                                class="btn-sm" style="background: #e74c3c;">
                            ✗ Reject
                        </button>
                    </div>
                </div>
            `).join('');
        } else {
            requestsList.innerHTML = '<p style="text-align: center; padding: 2rem; color: #666;">No pending requests at this time.</p>';
        }
    } catch (error) {
        console.error('Error loading requests:', error);
        document.getElementById('requests-list').innerHTML = '<p style="color: red; text-align: center;">Error loading requests</p>';
    }
}

// View requests for specific course
async function viewCourseRequests(courseId) {
    try {
        const response = await fetch(`manage_requests.php?course_id=${courseId}`);
        const data = await response.json();
        
        if (data.success && data.requests.length > 0) {
            const requestsHtml = data.requests.map(request => `
                <div style="margin-bottom: 15px; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                    <strong>${request.student_name}</strong> (${request.student_email})<br>
                    ${request.request_message ? `Message: ${request.request_message}<br>` : ''}
                    <small>Requested: ${new Date(request.requested_at).toLocaleString()}</small>
                </div>
            `).join('');
            
            Swal.fire({
                title: 'Course Join Requests',
                html: requestsHtml,
                width: '600px',
                confirmButtonText: 'Close'
            });
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// Handle approve/reject request
async function handleRequest(requestId, action) {
    const actionText = action === 'approve' ? 'approve' : 'reject';
    
    const result = await Swal.fire({
        title: `${action === 'approve' ? 'Approve' : 'Reject'} Request?`,
        text: `Are you sure you want to ${actionText} this student's request?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: action === 'approve' ? '#2ecc71' : '#e74c3c',
        cancelButtonColor: '#95a5a6',
        confirmButtonText: `Yes, ${actionText}!`,
        input: 'textarea',
        inputPlaceholder: 'Add a note (optional)...',
        inputAttributes: {
            'aria-label': 'Note'
        }
    });
    
    if (!result.isConfirmed) return;
    
    const note = result.value || '';
    
    // Show loading
    Swal.fire({
        title: 'Processing...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    try {
        const response = await fetch('manage_requests.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                request_id: requestId,
                action: action,
                note: note
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: data.message,
                confirmButtonColor: '#2ecc71'
            });
            loadPendingRequests(); // Reload requests
            loadFacultyCourses(); // Reload courses to update counts
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: data.message,
                confirmButtonColor: '#d33'
            });
        }
    } catch (error) {
        console.error('Error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Network Error',
            text: 'Could not connect to server',
            confirmButtonColor: '#d33'
        });
    }
}