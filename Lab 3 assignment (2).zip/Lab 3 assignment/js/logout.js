// Logout function
async function logout() {
  try {
    // Show confirmation dialog
    const result = await Swal.fire({
      title: 'Are you sure?',
      text: 'Do you want to log out?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, log out',
      cancelButtonText: 'Cancel'
    });

    if (!result.isConfirmed) {
      return;
    }

    // Show loading
    Swal.fire({
      title: 'Logging out...',
      allowOutsideClick: false,
      didOpen: () => {
        Swal.showLoading();
      }
    });

    // Send logout request
    const response = await fetch('logout.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    const data = await response.json();

    if (data.logout) {
      // Success message
      Swal.fire({
        icon: 'success',
        title: 'Logged Out',
        text: 'You have been successfully logged out.',
        confirmButtonColor: '#667eea',
        timer: 2000,
        timerProgressBar: true
      }).then(() => {
        // Redirect to login page
        window.location.href = 'Login.php';
      });
    } else {
      // Error message
      Swal.fire({
        icon: 'error',
        title: 'Logout Failed',
        text: data.message || 'Could not log out. Please try again.',
        confirmButtonColor: '#d33'
      });
    }

  } catch (error) {
    console.error('Error:', error);
    Swal.fire({
      icon: 'error',
      title: 'Network Error',
      text: 'Could not connect to server.',
      confirmButtonColor: '#d33'
    });
  }
}

// Add event listeners to all logout buttons when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  // Find all logout buttons (adjust selector based on your HTML)
  const logoutButtons = document.querySelectorAll('.logout-btn, [data-action="logout"]');
  
  logoutButtons.forEach(button => {
    button.addEventListener('click', function(e) {
      e.preventDefault();
      logout();
    });
  });
});