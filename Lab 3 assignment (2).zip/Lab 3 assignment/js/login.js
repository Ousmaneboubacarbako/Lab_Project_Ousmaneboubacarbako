// Load remembered email on page load
window.addEventListener('load', function() {
  const rememberedEmail = localStorage.getItem('rememberedEmail');
  if (rememberedEmail) {
    document.getElementById('email').value = rememberedEmail;
    document.getElementById('rememberMe').checked = true;
  }
  
  // Check for timeout parameter
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.get('timeout') === '1') {
    Swal.fire({
      icon: 'info',
      title: 'Session Expired',
      text: 'Your session has expired. Please log in again.',
      confirmButtonColor: '#667eea'
    });
  }
});

// Login form submission handler
document.getElementById('loginForm').addEventListener('submit', async function (e) {
  e.preventDefault();

  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const role = document.getElementById('signupRole').value;
  const rememberMe = document.getElementById('rememberMe').checked;

  // Client-side validation
  if (!email || !password || !role) {
    Swal.fire({
      icon: 'warning',
      title: 'Missing Information',
      text: 'Please fill in all fields',
      confirmButtonColor: '#f39c12'
    });
    return;
  }

  // Show loading
  Swal.fire({
    title: 'Logging in...',
    allowOutsideClick: false,
    didOpen: () => {
      Swal.showLoading();
    }
  });

  try {
    // Send login request
    const response = await fetch('login.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        email: email,
        password: password,
        role: role
      })
    });

    const data = await response.json();

    if (data.success) {
      // Handle "Remember Me" functionality
      if (rememberMe) {
        localStorage.setItem('rememberedEmail', email);
      } else {
        localStorage.removeItem('rememberedEmail');
      }

      // Success message
      Swal.fire({
        icon: 'success',
        title: 'Login Successful!',
        html: `Welcome back, <strong>${data.username}</strong>!`,
        confirmButtonColor: '#667eea',
        timer: 2000,
        timerProgressBar: true,
        showConfirmButton: false
      }).then(() => {
        // Redirect based on role
        switch(data.role) {
          case 'student':
            window.location.href = 'StuDashboard.php';
            break;
          case 'faculty':
            window.location.href = 'FDashboard.php';
            break;
          case 'fi':
            window.location.href = 'Dashboard.php';
            break;
          default:
            window.location.href = 'index.php';
        }
      });
    } else {
      // Error message
      Swal.fire({
        icon: 'error',
        title: 'Login Failed',
        text: data.message || 'Invalid credentials. Please try again.',
        confirmButtonColor: '#d33'
      });
    }

  } catch (error) {
    console.error('Error:', error);
    Swal.fire({
      icon: 'error',
      title: 'Network Error',
      text: 'Could not connect to server. Please try again.',
      confirmButtonColor: '#d33'
    });
  }
});