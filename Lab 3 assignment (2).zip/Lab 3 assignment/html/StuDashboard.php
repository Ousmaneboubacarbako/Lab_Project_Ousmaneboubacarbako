<?php
require_once 'auth_check.php';

// Only students can access this dashboard
if ($_SESSION['role'] !== 'student') {
    header('Location: Login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <!--<link rel="stylesheet" href="css/Stu.css">-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.7.32/sweetalert2.all.min.js"></script>
    <style>
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s;
        }
        
        .modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 30px;
            border-radius: 12px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 5px 30px rgba(0,0,0,0.3);
            animation: slideIn 0.3s;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close:hover { color: #000; }
        
        /* Course Card Styles */
        .course-card {
            background: #f8f9fa;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            border-left: 4px solid #3498db;
            transition: all 0.3s;
            position: relative;
        }
        
        .course-card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transform: translateX(5px);
        }
        
        .course-card h3 {
            margin: 0 0 10px 0;
            color: #3498db;
        }
        
        .course-info {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
            font-size: 14px;
            color: #666;
        }
        
        .course-meta {
            font-size: 13px;
            color: #888;
            margin-top: 5px;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
        }
        
        .badge-success { background: #d4edda; color: #155724; }
        .badge-warning { background: #fff3cd; color: #856404; }
        .badge-info { background: #d1ecf1; color: #0c5460; }
        .badge-danger { background: #f8d7da; color: #721c24; }
        
        /* Search Box */
        .search-box {
            margin-bottom: 20px;
        }
        
        .search-box input {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
        }
        
        .btn-join {
            background: #2ecc71;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-join:hover {
            background: #27ae60;
        }
        
        .btn-join:disabled {
            background: #95a5a6;
            cursor: not-allowed;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
        }
        
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 5px;
            resize: vertical;
            min-height: 80px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Student Dashboard</h1>
        <p>Welcome, <?php echo($_SESSION['username']); ?>!</p>
        <nav>
            <ul>
                <li><a href="#my-courses">My Courses</a></li>
                <li><a href="#available-courses">Available Courses</a></li>
                <li><a href="#session-schedule">Schedule</a></li>
                <li><a href="#" class="logout-btn">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <!-- My Enrolled Courses Section -->
        <section id="my-courses">
            <h2>My Enrolled Courses</h2>
            <div class="content-box">
                <div id="enrolled-courses-list">
                    <p style="text-align: center; color: #666;">Loading your courses...</p>
                </div>
            </div>
        </section>

        <!-- Available Courses Section -->
        <section id="available-courses">
            <h2>Available Courses to Join</h2>
            <div class="content-box">
                <div class="search-box">
                    <input type="text" id="courseSearch" placeholder="🔍 Search courses by name or code..." 
                           onkeyup="filterCourses()">
                </div>
                <button onclick="openBrowseCoursesModal()">Browse All Courses</button>
                <div id="available-courses-list">
                    <p style="text-align: center; color: #666;">Loading available courses...</p>
                </div>
            </div>
        </section>

        <section id="session-schedule">
            <h2>Session Schedule</h2>
            <div class="content-box" id="schedule-data">
                <p>Your upcoming sessions will be displayed here...</p>
            </div>
        </section>
    </main>

    <!-- Browse Courses Modal -->
    <div id="browseCoursesModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeBrowseCoursesModal()">&times;</span>
            <h2>All Available Courses</h2>
            <div class="search-box">
                <input type="text" id="modalCourseSearch" placeholder="🔍 Search..." 
                       onkeyup="filterModalCourses()">
            </div>
            <div id="modal-courses-list">
                <p style="text-align: center; color: #666;">Loading...</p>
            </div>
        </div>
    </div>

    <!-- Join Course Modal -->
    <div id="joinCourseModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeJoinCourseModal()">&times;</span>
            <h2>Request to Join Course</h2>
            <div id="joinCourseInfo"></div>
            <form id="joinCourseForm">
                <input type="hidden" id="join_course_id" name="course_id">
                <div class="form-group">
                    <label for="join_message">Message to Faculty (Optional)</label>
                    <textarea id="join_message" name="message" 
                              placeholder="Introduce yourself or explain why you want to join this course..."></textarea>
                </div>
                <button type="submit" class="btn">Send Join Request</button>
            </form>
        </div>
    </div>

    <script src="js/logout.js"></script>
    <script src="js/student_courses.js"></script>
</body>
</html>