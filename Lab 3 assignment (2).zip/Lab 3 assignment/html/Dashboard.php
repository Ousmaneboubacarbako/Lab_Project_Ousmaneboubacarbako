<?php
// Include authentication check redirects if not logged in
require_once 'auth_check.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Intern Dashboard</title>
    <link rel="stylesheet" href="css/FI.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.7.32/sweetalert2.all.min.js"></script>
</head>
<body>
    <header>
        <h1>Faculty Intern Dashboard</h1>
        <!-- Display logged-in user's name from session -->
        
        <p>Welcome, <?php echo($_SESSION['username']); ?>!</p>
        
        <!-- Navigation menu -->
        <nav>
            <ul>
                <li><a href="#Courses">Course List</a></li>
                <li><a href="#Sessions">Sessions</a></li>
                <li><a href="#Reports">Reports</a></li>
                <li><a href="#Students">Observers</a></li>
                <li><a href="#" class="logout-btn">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <!-- Course List Section -->
        <section id="Courses">
            <h2>Course list</h2>
            <div class="content-box" id="Course-data">
                <ul>
                    <li><a href="#">Web Technology</a></li>
                    <li><a href="#">Statistics</a></li>
                    <li><a href="#">Calculus</a></li>
                </ul>
            </div>
        </section>
        
        <!-- Sessions Section -->
        <section id="Session">
            <h2>Sessions</h2>
            <div class="content-box" id="Sessions-data">
                <p>Session data will be loaded here...</p>
            </div>
        </section>
        
        <!-- Reports Section -->
        <section id="report">
            <h2>Reports</h2>
            <div class="content-box" id="report-data">
                <p>Reports will be displayed here...</p>
            </div>
        </section>
        
        <!-- Observers Section -->
        <section id="student">
            <h2>Observers</h2>
            <div class="content-box" id="auditors-data">
                <p>Observer data will be displayed here...</p>
            </div>
        </section>
    </main>
    
    <script src="js/logout.js"></script>
</body>
</html>