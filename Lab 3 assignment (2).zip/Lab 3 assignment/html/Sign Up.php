<?php
// Start session
session_start();

// If user is already logged in, redirect to their dashboard
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    // Redirect based on user role
    switch($_SESSION['role']) {
        case 'student':
            header('Location: StuDashboard.php');
            break;
        case 'faculty':
            header('Location: FDashboard.php');
            break;
        case 'fi':
            header('Location: Dashboard.php');
            break;
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign Up - Attendance Manager</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.7.32/sweetalert2.all.min.js"></script>
  <link rel="stylesheet" href="css/Sign Up.css">
</head>
<body>
  <div class="wrapper">
    <form id="signupForm">
      <h1>Sign Up</h1>
      
      <!-- Role selection - required field -->
      <div class="form-group" style="margin-bottom: 20px;">
        <label for="signupRole" style="color: #fff; margin-bottom: 5px; display: block; font-weight: bold;">Select Role</label>
        <select id="signupRole" required style="width: 100%; padding: 10px; border-radius: 20px; border: 2px solid rgba(225,225,225,.2); background: rgba(201, 81, 81, 0.8); color: #fff; font-size: 16px;">
          <option value="">Choose your role</option>
          <option value="student">Student</option>
          <option value="faculty">Faculty</option>
          <option value="fi">Faculty Intern</option>
        </select>
      </div>

      <!-- First name input with validation pattern -->
      <div class="input-box">
        <input type="text" id="firstName" placeholder="First Name"
          pattern="[a-zA-Z\u00C0-\u017F]+([-'\s][a-zA-Z\u00C0-\u017F]+)*"
          title="Please enter a valid name"
          required>
        <small style="color: #fdfcfc; font-size: 12px; display: block; margin-top: 4px;">
          Only letters, spaces, hyphens, and apostrophes allowed
        </small>
      </div>

      <!-- Last name input with validation pattern -->
      <div class="input-box">
        <input type="text" id="lastName" placeholder="Last Name"
          pattern="[a-zA-Z\u00C0-\u017F]+([-'\s][a-zA-Z\u00C0-\u017F]+)*"
          title="Please enter a valid name"
          required>
        <small style="color: #fdfcfc; font-size: 12px; display: block; margin-top: 4px;">
          Only letters, spaces, hyphens, and apostrophes allowed
        </small>
      </div>

      <!-- Email input - automatically validates email format -->
      <div class="input-box">
        <input type="email" id="email" placeholder="Email" required>
      </div>

      <!-- Password input with minimum length requirement -->
      <div class="input-box">
        <input type="password" id="password" placeholder="Password"
          minlength="8"
          title="Password must be at least 8 characters" 
          required>
        <small style="color: #fdfcfc; font-size: 12px; display: block; margin-top: 4px;">
          Minimum 8 characters
        </small>
      </div>

      <!-- Confirm password input - must match password -->
      <div class="input-box">
        <input type="password" id="C_password" placeholder="Confirm Password" required>
      </div>
      
      <button type="submit" class="btn">Register</button>

      <!-- Link to login page -->
      <div class="Login">
        <p><a href="Login.php">I already have an Account</a></p>
      </div>
    </form>
  </div>

  <!-- Include JavaScript for form handling -->
  <script src="js/signup.js"></script>
</body>
</html>