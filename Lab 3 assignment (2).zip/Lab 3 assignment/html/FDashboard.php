<?php
require_once 'auth_check.php';

// Only faculty can access this dashboard
if ($_SESSION['role'] !== 'faculty') {
    header('Location: Login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Dashboard</title>
    <!--<link rel="stylesheet" href="css/F.css">-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.7.32/sweetalert2.all.min.js"></script>
    <style>
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s;
        }
        
        .modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 30px;
            border-radius: 12px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 5px 30px rgba(0,0,0,0.3);
            animation: slideIn 0.3s;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close:hover { color: #000; }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
        }
        
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        
        /* Course Card Styles */
        .course-card {
            background: #f8f9fa;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            border-left: 4px solid #a62039;
            transition: all 0.3s;
        }
        
        .course-card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transform: translateX(5px);
        }
        
        .course-card h3 {
            margin: 0 0 10px 0;
            color: #a62039;
        }
        
        .course-info {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
            font-size: 14px;
            color: #666;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
        }
        
        .badge-success { background: #d4edda; color: #155724; }
        .badge-warning { background: #fff3cd; color: #856404; }
        .badge-info { background: #d1ecf1; color: #0c5460; }
        
        /* Request Card Styles */
        .request-card {
            background: white;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            border: 1px solid #ddd;
        }
        
        .request-actions {
            margin-top: 10px;
            display: flex;
            gap: 10px;
        }
        
        .btn-sm {
            padding: 6px 15px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Faculty Dashboard</h1>
        <p>Welcome, <?php echo($_SESSION['username']); ?>!</p>
        <nav>
            <ul>
                <li><a href="#course-management">My Courses</a></li>
                <li><a href="#course-requests">Join Requests</a></li>
                <li><a href="#session-overview">Sessions</a></li>
                <li><a href="#" class="logout-btn">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <!-- Course Management Section -->
        <section id="course-management">
            <h2>Course Management</h2>
            <div class="content-box">
                <button onclick="openCreateCourseModal()">Create New Course</button>
                <div id="course-list">
                    <p style="text-align: center; color: #666;">Loading courses...</p>
                </div>
            </div>
        </section>

        <!-- Course Requests Section -->
        <section id="course-requests">
            <h2>Pending Join Requests</h2>
            <div class="content-box">
                <div id="requests-list">
                    <p style="text-align: center; color: #666;">Loading requests...</p>
                </div>
            </div>
        </section>

        <section id="session-overview">
            <h2>Session Overview</h2>
            <div class="content-box" id="session-data">
                <p>Session data will be loaded here...</p>
            </div>
        </section>
    </main>

    <!-- Create Course Modal -->
    <div id="createCourseModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeCreateCourseModal()">&times;</span>
            <h2>Create New Course</h2>
            <form id="createCourseForm">
                <div class="form-group">
                    <label for="course_code">Course Code *</label>
                    <input type="text" id="course_code" name="course_code" 
                           placeholder="e.g., CS101, MATH201" 
                           pattern="[A-Z]{2,4}\d{3}" 
                           title="Format: 2-4 letters + 3 digits (e.g., CS101)"
                           required>
                </div>
                
                <div class="form-group">
                    <label for="course_name">Course Name *</label>
                    <input type="text" id="course_name" name="course_name" 
                           placeholder="e.g., Introduction to Programming" required>
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" 
                              placeholder="Brief course description"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="credits">Credits</label>
                    <select id="credits" name="credits">
                        <option value="1">1 Credit</option>
                        <option value="2">2 Credits</option>
                        <option value="3" selected>3 Credits</option>
                        <option value="4">4 Credits</option>
                        <option value="5">5 Credits</option>
                        <option value="6">6 Credits</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="semester">Semester</label>
                    <input type="text" id="semester" name="semester" 
                           placeholder="e.g., Fall 2024">
                </div>
                
                <button type="submit" class="btn">Create Course</button>
            </form>
        </div>
    </div>

    <script src="js/logout.js"></script>
    <script src="js/faculty_courses.js"></script>
</body>
</html>