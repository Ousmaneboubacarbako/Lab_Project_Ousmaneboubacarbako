<?php
// Start session
session_start();

// If user is already logged in, redirect to their dashboard
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    // Redirect based on user role
    switch($_SESSION['role']) {
        case 'student':
            header('Location: StuDashboard.php');
            break;
        case 'faculty':
            header('Location: FDashboard.php');
            break;
        case 'fi':
            header('Location: Dashboard.php');
            break;
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Attendance Manager</title>
    <link rel="stylesheet" href="css/Login.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.7.32/sweetalert2.all.min.js"></script>
</head>
<body>
    <div class="wrapper">
        <form id="loginForm">
            <h1>Login</h1>
            
            <!-- Role selection dropdown -->
            <div class="form-group">
                <label for="signupRole">Select Role</label>
                <select id="signupRole" required>
                    <option value="">Choose your role</option>
                    <option value="student">Student</option>
                    <option value="faculty">Faculty</option>
                    <option value="fi">Faculty Intern</option>
                </select>
            </div>
            
            <!-- Email input -->
            <div class="input-box">
                <input type="text" id="email" placeholder="Email" required>    
            </div>

            <!-- Password input -->
            <div class="input-box">
                <input type="password" id="password" placeholder="Password" required>
            </div>

            <!-- Remember me checkbox and forgot password link -->
            <div class="remember-forgot">
                <label><input type="checkbox" id="rememberMe">Remember me</label> 
                <a href="#">Forget password</a>
            </div>
            
            <button type="submit" class="btn">Login</button>
            
            <!-- Link to registration page -->
            <div class="register-link">
                <p>Don't have an account? <a href="Sign Up.php">Register</a></p>
            </div>
        </form>
    </div>
    <script src="js/login.js"></script>
</body>
</html>